export type Role = "customer" | "pharmacist" | "admin";

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: Role;
  createdAt: number;
  favorites: string[]; // medicine ids
}

export interface Medicine {
  id: string;
  name: string;
  brand: string;
  generic: string;
  manufacturer: string;
  category: string;
  composition: string;
  form: string; // Tablet, Syrup, Injection, ...
  strength: string;
  uses: string[];
  directions: string;
  sideEffects: string[];
  contraindications: string[];
  storage: string;
  interactions: string[];
  warnings: string[];
  prescription: boolean;
  image: string; // emoji or url
  color: string;
  searches: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "bot";
  text: string;
  ts: number;
  medicineRefs?: string[];
  disclaimer?: boolean;
}

export interface ChatSession {
  id: string;
  userId: string;
  title: string;
  createdAt: number;
  messages: ChatMessage[];
}

export interface AuditLog {
  id: string;
  ts: number;
  actor: string;
  action: string;
  target?: string;
}
