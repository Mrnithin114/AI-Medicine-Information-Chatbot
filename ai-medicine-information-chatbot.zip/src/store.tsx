import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { AuditLog, ChatSession, Medicine, User } from "./types";
import { SEED_MEDICINES } from "./data/medicines";

const LS = {
  users: "medibot.users",
  current: "medibot.current",
  meds: "medibot.meds",
  chats: "medibot.chats",
  theme: "medibot.theme",
  audit: "medibot.audit",
};

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function save<T>(key: string, val: T) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* ignore */ }
}

const SEED_USERS: User[] = [
  { id: "u-admin", name: "Dr. Sarah Chen", email: "admin@medibot.health", password: "admin123", role: "admin", createdAt: Date.now() - 30 * 86400_000, favorites: [] },
  { id: "u-pharm", name: "Rohan Patel", email: "pharmacist@medibot.health", password: "pharma123", role: "pharmacist", createdAt: Date.now() - 14 * 86400_000, favorites: ["med-002", "med-005"] },
  { id: "u-cust", name: "Aisha Khan", email: "patient@medibot.health", password: "patient123", role: "customer", createdAt: Date.now() - 7 * 86400_000, favorites: ["med-001", "med-004"] },
];

interface Ctx {
  // theme
  theme: "light" | "dark";
  toggleTheme: () => void;
  // auth
  currentUser: User | null;
  users: User[];
  login: (email: string, password: string) => { ok: boolean; error?: string };
  register: (name: string, email: string, password: string, role: User["role"]) => { ok: boolean; error?: string };
  logout: () => void;
  toggleFavorite: (medId: string) => void;
  // medicines
  medicines: Medicine[];
  addMedicine: (m: Omit<Medicine, "id" | "searches">) => void;
  updateMedicine: (id: string, patch: Partial<Medicine>) => void;
  deleteMedicine: (id: string) => void;
  bumpSearch: (id: string) => void;
  // chats
  chats: ChatSession[];
  addChat: (session: ChatSession) => void;
  updateChat: (id: string, patch: Partial<ChatSession>) => void;
  deleteChat: (id: string) => void;
  // admin
  deleteUser: (id: string) => void;
  audit: AuditLog[];
  addAudit: (action: string, target?: string) => void;
}

const AppContext = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<"light" | "dark">(() => load(LS.theme, "light"));
  const [users, setUsers] = useState<User[]>(() => load(LS.users, SEED_USERS));
  const [currentUser, setCurrentUser] = useState<User | null>(() => load<User | null>(LS.current, null));
  const [medicines, setMedicines] = useState<Medicine[]>(() => load(LS.meds, SEED_MEDICINES));
  const [chats, setChats] = useState<ChatSession[]>(() => load(LS.chats, []));
  const [audit, setAudit] = useState<AuditLog[]>(() => load(LS.audit, []));

  useEffect(() => { save(LS.theme, theme); document.documentElement.classList.toggle("dark", theme === "dark"); }, [theme]);
  useEffect(() => { save(LS.users, users); }, [users]);
  useEffect(() => { save(LS.current, currentUser); }, [currentUser]);
  useEffect(() => { save(LS.meds, medicines); }, [medicines]);
  useEffect(() => { save(LS.chats, chats); }, [chats]);
  useEffect(() => { save(LS.audit, audit); }, [audit]);

  const addAudit = (action: string, target?: string) => {
    setAudit((a) => [{ id: `log-${Date.now()}`, ts: Date.now(), actor: currentUser?.email || "system", action, target }, ...a].slice(0, 200));
  };

  const ctx: Ctx = useMemo(() => ({
    theme,
    toggleTheme: () => setTheme((t) => (t === "light" ? "dark" : "light")),

    currentUser, users,
    login(email, password) {
      const u = users.find((x) => x.email.toLowerCase() === email.toLowerCase() && x.password === password);
      if (!u) return { ok: false, error: "Invalid email or password." };
      setCurrentUser(u);
      addAudit("user.login");
      return { ok: true };
    },
    register(name, email, password, role) {
      if (!name || !email || !password) return { ok: false, error: "All fields are required." };
      if (users.some((x) => x.email.toLowerCase() === email.toLowerCase())) return { ok: false, error: "Email already registered." };
      const u: User = { id: `u-${Date.now()}`, name, email, password, role, createdAt: Date.now(), favorites: [] };
      setUsers((arr) => [...arr, u]);
      setCurrentUser(u);
      addAudit("user.register", email);
      return { ok: true };
    },
    logout() { addAudit("user.logout"); setCurrentUser(null); },
    toggleFavorite(medId) {
      if (!currentUser) return;
      const fav = currentUser.favorites.includes(medId)
        ? currentUser.favorites.filter((x) => x !== medId)
        : [...currentUser.favorites, medId];
      const updated = { ...currentUser, favorites: fav };
      setCurrentUser(updated);
      setUsers((arr) => arr.map((u) => (u.id === updated.id ? updated : u)));
    },

    medicines,
    addMedicine(m) {
      const med: Medicine = { ...m, id: `med-${Date.now()}`, searches: 0 };
      setMedicines((arr) => [med, ...arr]);
      addAudit("medicine.create", med.name);
    },
    updateMedicine(id, patch) {
      setMedicines((arr) => arr.map((m) => (m.id === id ? { ...m, ...patch } : m)));
      addAudit("medicine.update", id);
    },
    deleteMedicine(id) {
      setMedicines((arr) => arr.filter((m) => m.id !== id));
      addAudit("medicine.delete", id);
    },
    bumpSearch(id) {
      setMedicines((arr) => arr.map((m) => (m.id === id ? { ...m, searches: m.searches + 1 } : m)));
    },

    chats,
    addChat(s) { setChats((arr) => [s, ...arr]); },
    updateChat(id, patch) { setChats((arr) => arr.map((c) => (c.id === id ? { ...c, ...patch } : c))); },
    deleteChat(id) { setChats((arr) => arr.filter((c) => c.id !== id)); },

    deleteUser(id) {
      setUsers((arr) => arr.filter((u) => u.id !== id));
      addAudit("user.delete", id);
    },
    audit, addAudit,
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [theme, users, currentUser, medicines, chats, audit]);

  return <AppContext.Provider value={ctx}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
