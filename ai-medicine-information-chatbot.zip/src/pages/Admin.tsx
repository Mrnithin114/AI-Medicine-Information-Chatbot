import { useMemo, useState } from "react";
import { useApp } from "../store";
import { Badge, Button, Card, Input, Modal, Select, Textarea } from "../components/ui";
import type { Medicine } from "../types";

/* ============= DASHBOARD ============= */
export function Dashboard() {
  const { users, medicines, chats, audit } = useApp();

  const queryCount = chats.reduce((a, c) => a + c.messages.filter((m) => m.role === "user").length, 0);
  const topMeds = [...medicines].sort((a, b) => b.searches - a.searches).slice(0, 6);
  const maxSearches = Math.max(1, ...topMeds.map((m) => m.searches));

  const categories = useMemo(() => {
    const map = new Map<string, number>();
    medicines.forEach((m) => map.set(m.category, (map.get(m.category) || 0) + m.searches));
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5);
  }, [medicines]);
  const totalCat = Math.max(1, categories.reduce((a, [, n]) => a + n, 0));

  // daily stats — simulated buckets based on chats
  const daily = useMemo(() => {
    const arr = new Array(7).fill(0);
    chats.forEach((c) => {
      const days = Math.floor((Date.now() - c.createdAt) / 86400_000);
      if (days >= 0 && days < 7) arr[6 - days] += c.messages.length;
    });
    // add some baseline so it doesn't look empty
    return arr.map((v, i) => v + 40 + i * 8 + Math.floor(Math.random() * 30));
  }, [chats]);
  const maxDaily = Math.max(...daily);

  return (
    <div className="p-4 lg:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
        <p className="text-slate-500 text-sm mt-1">Real-time overview of MediBot usage and content.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KPI label="Total Users" value={users.length} delta="+12%" icon="👥" color="from-brand-500 to-cyan-500" />
        <KPI label="Total Medicines" value={medicines.length} delta="+3" icon="💊" color="from-emerald-500 to-teal-500" />
        <KPI label="Total Queries" value={queryCount} delta="+24%" icon="❓" color="from-violet-500 to-fuchsia-500" />
        <KPI label="Active Sessions" value={chats.length} delta="+8%" icon="💬" color="from-amber-500 to-orange-500" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold">Daily Chat Activity</h3>
            <Badge color="green">Last 7 days</Badge>
          </div>
          <div className="flex items-end justify-between gap-3 h-48">
            {daily.map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center justify-end gap-2">
                <div className="text-xs font-medium tabular-nums">{v}</div>
                <div className="w-full rounded-t-lg bg-gradient-to-t from-brand-500 to-cyan-400 transition-all hover:opacity-80" style={{ height: `${(v / maxDaily) * 100}%`, minHeight: 6 }} />
                <div className="text-xs text-slate-500">{["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i]}</div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold mb-5">Popular Categories</h3>
          <div className="space-y-3">
            {categories.map(([cat, n]) => (
              <div key={cat}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="truncate">{cat}</span>
                  <span className="text-slate-500 tabular-nums">{n}</span>
                </div>
                <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div className="h-full rounded-full bg-gradient-to-r from-brand-500 to-cyan-500" style={{ width: `${(n / totalCat) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Most Searched Medicines</h3>
          <div className="space-y-3">
            {topMeds.map((m, i) => (
              <div key={m.id} className="flex items-center gap-3">
                <div className="w-6 text-center text-sm font-bold text-slate-400">{i + 1}</div>
                <div className={`h-10 w-10 rounded-lg bg-gradient-to-br ${m.color} flex items-center justify-center text-lg`}>{m.image}</div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{m.brand}</p>
                  <p className="text-xs text-slate-500 truncate">{m.generic}</p>
                </div>
                <div className="w-32">
                  <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-brand-500 to-cyan-500" style={{ width: `${(m.searches / maxSearches) * 100}%` }} />
                  </div>
                </div>
                <span className="text-sm font-medium tabular-nums w-12 text-right">{m.searches}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-3 max-h-80 overflow-y-auto thin-scroll">
            {audit.slice(0, 12).map((l) => (
              <div key={l.id} className="flex items-start gap-3 text-sm">
                <div className="h-8 w-8 rounded-full bg-brand-100 dark:bg-brand-900/30 flex items-center justify-center text-xs shrink-0">📌</div>
                <div className="flex-1 min-w-0">
                  <p><span className="font-medium">{l.actor}</span> <span className="text-slate-500">{l.action}</span> {l.target && <span className="text-brand-600">{l.target}</span>}</p>
                  <p className="text-xs text-slate-400">{new Date(l.ts).toLocaleString()}</p>
                </div>
              </div>
            ))}
            {audit.length === 0 && <p className="text-center text-sm text-slate-500 py-4">No activity yet</p>}
          </div>
        </Card>
      </div>
    </div>
  );
}

function KPI({ label, value, delta, icon, color }: { label: string; value: number; delta: string; icon: string; color: string }) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center text-lg shadow-md`}>{icon}</div>
        <Badge color="green">{delta}</Badge>
      </div>
      <p className="text-3xl font-bold tabular-nums">{value.toLocaleString()}</p>
      <p className="text-xs text-slate-500 mt-1 uppercase tracking-wide">{label}</p>
    </Card>
  );
}

/* ============= MEDICINE MANAGEMENT ============= */
const EMPTY_MED: Omit<Medicine, "id" | "searches"> = {
  name: "", brand: "", generic: "", manufacturer: "", category: "", composition: "",
  form: "Tablet", strength: "", uses: [], directions: "", sideEffects: [], contraindications: [],
  storage: "", interactions: [], warnings: [], prescription: false, image: "💊", color: "from-brand-400 to-cyan-500",
};

export function MedicinesAdmin() {
  const { medicines, addMedicine, updateMedicine, deleteMedicine } = useApp();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Medicine | null>(null);
  const [form, setForm] = useState(EMPTY_MED);

  const filtered = medicines.filter((m) =>
    !q || [m.brand, m.generic, m.category].join(" ").toLowerCase().includes(q.toLowerCase())
  );

  const startNew = () => { setEditing(null); setForm(EMPTY_MED); setOpen(true); };
  const startEdit = (m: Medicine) => { setEditing(m); setForm({ ...m }); setOpen(true); };

  const save = () => {
    if (!form.brand || !form.generic) { alert("Brand and generic name required"); return; }
    if (editing) updateMedicine(editing.id, form);
    else addMedicine(form);
    setOpen(false);
  };

  const splitList = (s: string) => s.split("\n").map((x) => x.trim()).filter(Boolean);

  return (
    <div className="p-4 lg:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Medicine Database</h1>
          <p className="text-slate-500 text-sm mt-1">{medicines.length} medicines in the approved knowledge base.</p>
        </div>
        <div className="flex gap-2">
          <Input placeholder="Search…" value={q} onChange={(e) => setQ(e.target.value)} className="!h-10 w-64" />
          <Button onClick={startNew}>+ Add medicine</Button>
        </div>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 dark:bg-slate-900/50 text-xs uppercase text-slate-500">
            <tr>
              <th className="text-left p-4">Medicine</th>
              <th className="text-left p-4">Category</th>
              <th className="text-left p-4">Form</th>
              <th className="text-left p-4">Mfr.</th>
              <th className="text-left p-4">Rx</th>
              <th className="text-left p-4">Searches</th>
              <th className="text-right p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((m) => (
              <tr key={m.id} className="border-t border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900/40">
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <div className={`h-10 w-10 rounded-lg bg-gradient-to-br ${m.color} flex items-center justify-center text-lg`}>{m.image}</div>
                    <div>
                      <p className="font-medium">{m.brand}</p>
                      <p className="text-xs text-slate-500">{m.generic}</p>
                    </div>
                  </div>
                </td>
                <td className="p-4 text-slate-600 dark:text-slate-300">{m.category}</td>
                <td className="p-4"><Badge color="slate">{m.form}</Badge></td>
                <td className="p-4 text-slate-600 dark:text-slate-300">{m.manufacturer}</td>
                <td className="p-4">{m.prescription ? <Badge color="red">Rx</Badge> : <Badge color="green">OTC</Badge>}</td>
                <td className="p-4 tabular-nums">{m.searches}</td>
                <td className="p-4 text-right">
                  <div className="flex justify-end gap-2">
                    <Button size="sm" variant="outline" onClick={() => startEdit(m)}>Edit</Button>
                    <Button size="sm" variant="ghost" onClick={() => { if (confirm(`Delete ${m.brand}?`)) deleteMedicine(m.id); }} className="!text-rose-600">Delete</Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? `Edit: ${editing.brand}` : "Add new medicine"}>
        <div className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Brand name *"><Input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} /></Field>
            <Field label="Generic name *"><Input value={form.generic} onChange={(e) => setForm({ ...form, generic: e.target.value })} /></Field>
            <Field label="Display name"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="Manufacturer"><Input value={form.manufacturer} onChange={(e) => setForm({ ...form, manufacturer: e.target.value })} /></Field>
            <Field label="Category"><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></Field>
            <Field label="Form">
              <Select value={form.form} onChange={(e) => setForm({ ...form, form: e.target.value })} className="w-full">
                {["Tablet", "Capsule", "Syrup", "Injection", "Inhaler", "Softgel", "Cream", "Drops"].map((f) => <option key={f}>{f}</option>)}
              </Select>
            </Field>
            <Field label="Strength"><Input value={form.strength} onChange={(e) => setForm({ ...form, strength: e.target.value })} /></Field>
            <Field label="Composition"><Input value={form.composition} onChange={(e) => setForm({ ...form, composition: e.target.value })} /></Field>
            <Field label="Image / Emoji"><Input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} /></Field>
            <Field label="Card color (tailwind)"><Input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} /></Field>
          </div>
          <Field label="Directions for use"><Textarea value={form.directions} onChange={(e) => setForm({ ...form, directions: e.target.value })} /></Field>
          <div className="grid sm:grid-cols-2 gap-3">
            <Field label="Uses (one per line)"><Textarea value={form.uses.join("\n")} onChange={(e) => setForm({ ...form, uses: splitList(e.target.value) })} /></Field>
            <Field label="Side effects (one per line)"><Textarea value={form.sideEffects.join("\n")} onChange={(e) => setForm({ ...form, sideEffects: splitList(e.target.value) })} /></Field>
            <Field label="Contraindications"><Textarea value={form.contraindications.join("\n")} onChange={(e) => setForm({ ...form, contraindications: splitList(e.target.value) })} /></Field>
            <Field label="Drug interactions"><Textarea value={form.interactions.join("\n")} onChange={(e) => setForm({ ...form, interactions: splitList(e.target.value) })} /></Field>
            <Field label="Warnings & precautions"><Textarea value={form.warnings.join("\n")} onChange={(e) => setForm({ ...form, warnings: splitList(e.target.value) })} /></Field>
            <Field label="Storage instructions"><Textarea value={form.storage} onChange={(e) => setForm({ ...form, storage: e.target.value })} /></Field>
          </div>
          <Field label="Upload product document (optional)">
            <div className="border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl p-4 text-center text-sm text-slate-500">
              📎 Drop PDF here or <button className="text-brand-600 underline">browse files</button>
            </div>
          </Field>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.prescription} onChange={(e) => setForm({ ...form, prescription: e.target.checked })} className="h-4 w-4 rounded" />
            Prescription required
          </label>
          <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save}>{editing ? "Save changes" : "Add medicine"}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5 block">{label}</label>
      {children}
    </div>
  );
}

/* ============= USERS ============= */
export function UsersAdmin() {
  const { users, deleteUser, currentUser } = useApp();
  const [filter, setFilter] = useState("all");
  const list = filter === "all" ? users : users.filter((u) => u.role === filter);

  return (
    <div className="p-4 lg:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">User Management</h1>
          <p className="text-slate-500 text-sm mt-1">{users.length} total users across all roles.</p>
        </div>
        <Select value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="all">All roles</option>
          <option value="customer">Customers</option>
          <option value="pharmacist">Pharmacists</option>
          <option value="admin">Admins</option>
        </Select>
      </div>

      <Card>
        <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 dark:bg-slate-900/50 text-xs uppercase text-slate-500">
            <tr>
              <th className="text-left p-4">User</th>
              <th className="text-left p-4">Email</th>
              <th className="text-left p-4">Role</th>
              <th className="text-left p-4">Favorites</th>
              <th className="text-left p-4">Joined</th>
              <th className="text-right p-4">Actions</th>
            </tr>
          </thead>
          <tbody>
            {list.map((u) => (
              <tr key={u.id} className="border-t border-slate-100 dark:border-slate-800">
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="h-9 w-9 rounded-full bg-gradient-to-br from-brand-500 to-cyan-500 text-white font-medium flex items-center justify-center">{u.name.charAt(0)}</div>
                    <span className="font-medium">{u.name}</span>
                  </div>
                </td>
                <td className="p-4 text-slate-600 dark:text-slate-300">{u.email}</td>
                <td className="p-4">
                  <Badge color={u.role === "admin" ? "violet" : u.role === "pharmacist" ? "brand" : "green"}>{u.role}</Badge>
                </td>
                <td className="p-4 tabular-nums">{u.favorites.length}</td>
                <td className="p-4 text-slate-500">{new Date(u.createdAt).toLocaleDateString()}</td>
                <td className="p-4 text-right">
                  <Button size="sm" variant="ghost" disabled={u.id === currentUser?.id} className="!text-rose-600"
                    onClick={() => { if (confirm(`Delete ${u.name}?`)) deleteUser(u.id); }}>
                    Delete
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </Card>
    </div>
  );
}

/* ============= REPORTS ============= */
export function Reports() {
  const { users, medicines, chats } = useApp();
  const totalQueries = chats.reduce((a, c) => a + c.messages.filter((m) => m.role === "user").length, 0);

  const usersByRole = {
    customer: users.filter((u) => u.role === "customer").length,
    pharmacist: users.filter((u) => u.role === "pharmacist").length,
    admin: users.filter((u) => u.role === "admin").length,
  };
  const totalU = users.length || 1;

  const downloadCSV = () => {
    const rows = [
      ["Metric", "Value"],
      ["Total users", String(users.length)],
      ["Customers", String(usersByRole.customer)],
      ["Pharmacists", String(usersByRole.pharmacist)],
      ["Admins", String(usersByRole.admin)],
      ["Total medicines", String(medicines.length)],
      ["Total chats", String(chats.length)],
      ["Total user queries", String(totalQueries)],
      [],
      ["Medicine", "Brand", "Searches"],
      ...medicines.map((m) => [m.name, m.brand, String(m.searches)]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${c.replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "medibot_report.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 lg:p-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Reports & Analytics</h1>
          <p className="text-slate-500 text-sm mt-1">Export aggregate insights from your MediBot deployment.</p>
        </div>
        <Button onClick={downloadCSV}>⬇ Export CSV</Button>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h3 className="font-semibold mb-4">Users by Role</h3>
          <div className="space-y-4">
            {Object.entries(usersByRole).map(([role, n]) => (
              <div key={role}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="capitalize">{role}s</span>
                  <span className="text-slate-500">{n} ({Math.round((n / totalU) * 100)}%)</span>
                </div>
                <div className="h-3 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div className={`h-full rounded-full ${role === "admin" ? "bg-violet-500" : role === "pharmacist" ? "bg-brand-500" : "bg-emerald-500"}`}
                    style={{ width: `${(n / totalU) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-semibold mb-4">Summary</h3>
          <dl className="grid grid-cols-2 gap-4 text-sm">
            <Metric label="Total users" value={users.length} />
            <Metric label="Total medicines" value={medicines.length} />
            <Metric label="Total conversations" value={chats.length} />
            <Metric label="Total queries" value={totalQueries} />
          </dl>
        </Card>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40">
      <p className="text-xs text-slate-500 uppercase tracking-wide">{label}</p>
      <p className="text-2xl font-bold mt-1 tabular-nums">{value}</p>
    </div>
  );
}

/* ============= AUDIT LOGS ============= */
export function Logs() {
  const { audit } = useApp();
  return (
    <div className="p-4 lg:p-8 max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Audit Logs</h1>
        <p className="text-slate-500 text-sm mt-1">Immutable trail of all actions taken on the platform.</p>
      </div>
      <Card className="p-2">
        {audit.length === 0 ? (
          <p className="p-10 text-center text-slate-500">No actions logged yet.</p>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {audit.map((l) => (
              <li key={l.id} className="p-4 flex items-start gap-3">
                <div className="h-8 w-8 rounded-full bg-brand-100 dark:bg-brand-900/30 flex items-center justify-center text-xs shrink-0">📝</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm"><span className="font-medium">{l.actor}</span> · <code className="text-brand-600">{l.action}</code> {l.target && <>→ <span className="text-slate-700 dark:text-slate-300">{l.target}</span></>}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{new Date(l.ts).toLocaleString()}</p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
