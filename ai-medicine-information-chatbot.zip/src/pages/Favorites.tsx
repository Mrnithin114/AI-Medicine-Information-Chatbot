import { useApp } from "../store";
import { MedicineCard } from "../components/MedicineCard";
import { Card } from "../components/ui";
import type { Medicine } from "../types";

export function Favorites({ onOpen }: { onOpen: (m: Medicine) => void }) {
  const { currentUser, medicines } = useApp();
  const favs = medicines.filter((m) => currentUser?.favorites.includes(m.id));

  return (
    <div className="p-4 lg:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Favorite Medicines</h1>
        <p className="text-slate-500 text-sm mt-1">Medicines you've saved for quick access.</p>
      </div>
      {favs.length === 0 ? (
        <Card className="p-12 text-center text-slate-500">
          <div className="text-5xl mb-3">♡</div>
          <p className="font-medium text-slate-700 dark:text-slate-300">No favorites yet</p>
          <p className="text-sm mt-1">Browse medicines and tap the heart to save them here.</p>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {favs.map((m) => <MedicineCard key={m.id} m={m} onOpen={onOpen} />)}
        </div>
      )}
    </div>
  );
}
