import { useMemo, useState } from "react";
import { useApp } from "../store";
import { Badge, Card, Select } from "../components/ui";
import type { Medicine } from "../types";

export function Compare() {
  const { medicines } = useApp();
  const [aId, setAId] = useState(medicines[0]?.id || "");
  const [bId, setBId] = useState(medicines[1]?.id || "");
  const a = medicines.find((m) => m.id === aId);
  const b = medicines.find((m) => m.id === bId);

  const rows: { label: string; get: (m: Medicine) => string | string[] }[] = [
    { label: "Generic name", get: (m) => m.generic },
    { label: "Manufacturer", get: (m) => m.manufacturer },
    { label: "Category", get: (m) => m.category },
    { label: "Form", get: (m) => m.form },
    { label: "Strength", get: (m) => m.strength },
    { label: "Composition", get: (m) => m.composition },
    { label: "Prescription required", get: (m) => (m.prescription ? "Yes" : "No") },
    { label: "Uses", get: (m) => m.uses },
    { label: "Side effects", get: (m) => m.sideEffects },
    { label: "Contraindications", get: (m) => m.contraindications },
    { label: "Storage", get: (m) => m.storage },
  ];

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Product Comparison</h1>
        <p className="text-slate-500 text-sm mt-1">Compare two medicines side by side.</p>
      </div>

      <Card className="p-5">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-medium mb-1.5 block">Medicine A</label>
            <Select value={aId} onChange={(e) => setAId(e.target.value)} className="w-full">
              {medicines.map((m) => <option key={m.id} value={m.id}>{m.brand} — {m.generic}</option>)}
            </Select>
          </div>
          <div>
            <label className="text-xs font-medium mb-1.5 block">Medicine B</label>
            <Select value={bId} onChange={(e) => setBId(e.target.value)} className="w-full">
              {medicines.map((m) => <option key={m.id} value={m.id}>{m.brand} — {m.generic}</option>)}
            </Select>
          </div>
        </div>
      </Card>

      {a && b && (
        <Card className="overflow-hidden">
          <div className="grid grid-cols-3 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800">
            <div className="p-4" />
            <Header m={a} />
            <Header m={b} />
          </div>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {rows.map((r) => (
              <div key={r.label} className="grid grid-cols-3 text-sm">
                <div className="p-4 font-medium text-slate-600 dark:text-slate-400 bg-slate-50/50 dark:bg-slate-900/40">{r.label}</div>
                <Cell v={r.get(a)} />
                <Cell v={r.get(b)} />
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

function Header({ m }: { m: Medicine }) {
  return (
    <div className="p-4 text-center">
      <div className={`h-12 w-12 mx-auto rounded-xl bg-gradient-to-br ${m.color} flex items-center justify-center text-2xl shadow`}>{m.image}</div>
      <p className="mt-2 font-bold">{m.brand}</p>
      <p className="text-xs text-slate-500">{m.generic}</p>
    </div>
  );
}
function Cell({ v }: { v: string | string[] }) {
  if (Array.isArray(v)) return (
    <div className="p-4">
      <ul className="space-y-0.5 text-slate-700 dark:text-slate-300">{v.map((x, i) => <li key={i}>• {x}</li>)}</ul>
    </div>
  );
  return <div className="p-4 text-slate-700 dark:text-slate-300">{v}</div>;
}

/* ---------- Drug interactions ---------- */
export function Interactions() {
  const { medicines } = useApp();
  const [selected, setSelected] = useState<string[]>([]);

  const toggle = (id: string) => setSelected((s) => s.includes(id) ? s.filter((x) => x !== id) : [...s, id]);

  const issues = useMemo(() => {
    const meds = selected.map((id) => medicines.find((m) => m.id === id)).filter(Boolean) as Medicine[];
    const found: { a: Medicine; b: Medicine; reason: string; severity: "high" | "med" | "low" }[] = [];
    for (let i = 0; i < meds.length; i++) {
      for (let j = i + 1; j < meds.length; j++) {
        const a = meds[i]; const b = meds[j];
        const aText = (a.interactions.join(" ") + " " + a.contraindications.join(" ")).toLowerCase();
        const bText = (b.interactions.join(" ") + " " + b.contraindications.join(" ")).toLowerCase();
        const matchA = a.interactions.find((x) => bText.includes(x.toLowerCase().split(" ")[0]) || b.generic.toLowerCase().includes(x.toLowerCase().split(" ")[0]));
        const matchB = b.interactions.find((x) => aText.includes(x.toLowerCase().split(" ")[0]) || a.generic.toLowerCase().includes(x.toLowerCase().split(" ")[0]));
        if (matchA || matchB) {
          const severity = (matchA && /bleed|toxic|severe/i.test(matchA)) || (matchB && /bleed|toxic|severe/i.test(matchB)) ? "high" : "med";
          found.push({ a, b, reason: matchA || matchB || "Potential overlap", severity: severity as "high" | "med" });
        } else if (a.category === b.category) {
          found.push({ a, b, reason: `Both are ${a.category}s — possible additive effect`, severity: "low" });
        }
      }
    }
    return found;
  }, [selected, medicines]);

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Drug Interaction Lookup</h1>
        <p className="text-slate-500 text-sm mt-1">Select 2+ medicines to check for known interactions in our database.</p>
      </div>

      <Card className="p-5">
        <p className="text-sm font-medium mb-3">Select medicines ({selected.length} selected)</p>
        <div className="flex flex-wrap gap-2">
          {medicines.map((m) => (
            <button key={m.id} onClick={() => toggle(m.id)}>
              <Badge color={selected.includes(m.id) ? "brand" : "slate"}>
                {selected.includes(m.id) ? "✓ " : ""}{m.brand}
              </Badge>
            </button>
          ))}
        </div>
      </Card>

      {selected.length < 2 ? (
        <Card className="p-10 text-center text-slate-500">
          <div className="text-4xl mb-2">⚖️</div>
          Select at least two medicines to check for interactions.
        </Card>
      ) : issues.length === 0 ? (
        <Card className="p-10 text-center">
          <div className="text-4xl mb-2">✅</div>
          <p className="font-medium text-emerald-700 dark:text-emerald-400">No known interactions found in our database</p>
          <p className="text-sm text-slate-500 mt-1">Always double-check with a clinical pharmacist.</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {issues.map((i, idx) => (
            <Card key={idx} className="p-5">
              <div className="flex items-start gap-4">
                <div className={`h-12 w-12 rounded-xl flex items-center justify-center text-2xl shrink-0 ${i.severity === "high" ? "bg-rose-100 dark:bg-rose-900/30 text-rose-600" : i.severity === "med" ? "bg-amber-100 dark:bg-amber-900/30 text-amber-600" : "bg-slate-100 dark:bg-slate-800 text-slate-600"}`}>
                  {i.severity === "high" ? "🚨" : i.severity === "med" ? "⚠️" : "ℹ️"}
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="font-semibold">{i.a.brand}</span>
                    <span className="text-slate-400">×</span>
                    <span className="font-semibold">{i.b.brand}</span>
                    <Badge color={i.severity === "high" ? "red" : i.severity === "med" ? "amber" : "slate"}>
                      {i.severity === "high" ? "High severity" : i.severity === "med" ? "Moderate" : "Informational"}
                    </Badge>
                  </div>
                  <p className="text-sm text-slate-600 dark:text-slate-300">{i.reason}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- Customer queries ---------- */
export function Queries() {
  const { chats, users } = useApp();
  const customerChats = chats.filter((c) => users.find((u) => u.id === c.userId)?.role === "customer");

  return (
    <div className="p-4 lg:p-8 max-w-6xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Customer Query History</h1>
        <p className="text-slate-500 text-sm mt-1">Recent questions asked by patients across the platform.</p>
      </div>

      <Card>
        <table className="w-full text-sm">
          <thead className="bg-slate-50 dark:bg-slate-900/50 text-xs uppercase text-slate-500">
            <tr>
              <th className="text-left p-4">Customer</th>
              <th className="text-left p-4">Topic</th>
              <th className="text-left p-4">Messages</th>
              <th className="text-left p-4">Date</th>
            </tr>
          </thead>
          <tbody>
            {customerChats.length === 0 && (
              <tr><td colSpan={4} className="p-10 text-center text-slate-500">No customer conversations yet.</td></tr>
            )}
            {customerChats.map((c) => {
              const u = users.find((x) => x.id === c.userId);
              return (
                <tr key={c.id} className="border-t border-slate-100 dark:border-slate-800">
                  <td className="p-4 font-medium">{u?.name || "Unknown"}</td>
                  <td className="p-4 text-slate-700 dark:text-slate-300 truncate max-w-xs">{c.title}</td>
                  <td className="p-4"><Badge color="brand">{c.messages.length}</Badge></td>
                  <td className="p-4 text-slate-500">{new Date(c.createdAt).toLocaleString()}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}
