import { Button } from "../components/ui";
import { MediBotLogo } from "../components/Layout";
import type { PageKey } from "../components/Layout";
import { useApp } from "../store";

export function Landing({ setPage }: { setPage: (p: PageKey) => void }) {
  const { theme, toggleTheme } = useApp();

  const features = [
    { icon: "💬", title: "Natural Conversation", text: "Ask in plain English about uses, dosage, side effects, storage and more." },
    { icon: "🔬", title: "Approved Data", text: "Answers grounded in your company-approved medicine knowledge base." },
    { icon: "⚠️", title: "Safety First", text: "Built-in disclaimers, no diagnosis or prescription — emergency guidance always shown." },
    { icon: "👥", title: "Role-Based Access", text: "Tailored portals for patients, pharmacists and administrators." },
    { icon: "📊", title: "Analytics Dashboard", text: "Track queries, popular medicines and user activity in real time." },
    { icon: "🌍", title: "Multi-Language Ready", text: "Voice search & speech-to-text help every patient get answers, fast." },
  ];

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      {/* Nav */}
      <header className="sticky top-0 z-30 bg-white/80 dark:bg-slate-950/80 backdrop-blur border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <MediBotLogo />
          <nav className="hidden md:flex items-center gap-8 text-sm text-slate-600 dark:text-slate-300">
            <a href="#features" className="hover:text-brand-600">Features</a>
            <a href="#roles" className="hover:text-brand-600">For Teams</a>
            <a href="#safety" className="hover:text-brand-600">Safety</a>
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={toggleTheme}>{theme === "light" ? "🌙" : "☀️"}</Button>
            <Button variant="outline" size="sm" onClick={() => setPage("login")}>Sign in</Button>
            <Button size="sm" onClick={() => setPage("register")}>Get started</Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-60" />
        <div className="absolute -top-32 -right-32 h-96 w-96 rounded-full bg-cyan-300/40 dark:bg-cyan-500/20 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 h-96 w-96 rounded-full bg-brand-300/40 dark:bg-brand-500/20 blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-6 pt-16 pb-24 grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-fade-up">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 dark:bg-brand-900/40 text-brand-800 dark:text-brand-200 text-xs font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500" />
              </span>
              Powered by AI · HIPAA-conscious design
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05] tracking-tight">
              Instant, accurate <span className="bg-gradient-to-r from-brand-500 to-cyan-500 bg-clip-text text-transparent">medicine answers</span> — for everyone in healthcare.
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-300 max-w-xl">
              MediBot is an AI-powered medicine information assistant for pharmaceutical companies, pharmacies and hospitals. Trained on your approved product data, it serves patients, pharmacists and administrators from one secure platform.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button size="lg" onClick={() => setPage("register")}>Start free →</Button>
              <Button size="lg" variant="outline" onClick={() => setPage("login")}>Live demo</Button>
            </div>
            <div className="flex items-center gap-5 pt-4 text-sm text-slate-500">
              <div><span className="text-2xl font-bold text-slate-900 dark:text-slate-100">12K+</span> queries/day</div>
              <div className="h-8 w-px bg-slate-300 dark:bg-slate-700" />
              <div><span className="text-2xl font-bold text-slate-900 dark:text-slate-100">98%</span> accuracy</div>
              <div className="h-8 w-px bg-slate-300 dark:bg-slate-700" />
              <div><span className="text-2xl font-bold text-slate-900 dark:text-slate-100">24/7</span> uptime</div>
            </div>
          </div>

          {/* Mock chat preview */}
          <div className="relative animate-fade-up">
            <div className="absolute -inset-4 bg-gradient-to-tr from-brand-500/30 to-cyan-500/30 rounded-3xl blur-2xl" />
            <div className="relative rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="h-2.5 w-2.5 rounded-full bg-rose-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                </div>
                <div className="text-xs text-slate-500">medibot.health/chat</div>
                <div />
              </div>
              <div className="p-5 space-y-4 bg-slate-50/50 dark:bg-slate-950/50 h-[420px]">
                <div className="flex justify-end">
                  <div className="max-w-[80%] bg-brand-500 text-white rounded-2xl rounded-tr-sm px-4 py-2.5 text-sm shadow">
                    What is Paracetamol 500mg used for?
                  </div>
                </div>
                <div className="flex gap-3 animate-fade-up">
                  <div className="h-8 w-8 rounded-full bg-gradient-to-br from-brand-500 to-cyan-500 flex items-center justify-center text-white text-sm">🤖</div>
                  <div className="max-w-[85%] bg-white dark:bg-slate-800 rounded-2xl rounded-tl-sm px-4 py-3 text-sm shadow border border-slate-200 dark:border-slate-700">
                    <p className="font-semibold mb-1">Calpol (Paracetamol) is used for:</p>
                    <ul className="space-y-1 text-slate-700 dark:text-slate-300">
                      <li>• Mild to moderate pain relief</li>
                      <li>• Fever reduction</li>
                      <li>• Headache, toothache, cold & flu</li>
                    </ul>
                    <div className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-700 text-xs text-amber-700 dark:text-amber-300">
                      ⚠️ For information only — consult your physician.
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  {["Dosage?", "Side effects", "Storage"].map((s) => (
                    <span key={s} className="text-xs px-3 py-1.5 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300">{s}</span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 bg-slate-50 dark:bg-slate-900/40">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12 max-w-2xl mx-auto">
            <h2 className="text-3xl sm:text-4xl font-bold">Everything your healthcare team needs</h2>
            <p className="mt-3 text-slate-600 dark:text-slate-400">From conversational answers to deep analytics — built specifically for regulated environments.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f) => (
              <div key={f.title} className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:shadow-xl hover:-translate-y-1 transition">
                <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-brand-500/15 to-cyan-500/15 flex items-center justify-center text-2xl mb-4">{f.icon}</div>
                <h3 className="font-semibold mb-1">{f.title}</h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Roles */}
      <section id="roles" className="py-20">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-3 gap-6">
          {[
            { role: "Patients", color: "from-emerald-400 to-teal-500", points: ["Ask anything in plain language", "Save favorite medicines", "Download info sheets as PDF", "Persistent chat history"] },
            { role: "Pharmacists", color: "from-brand-500 to-cyan-500", points: ["Advanced semantic search", "Side-by-side comparison", "Drug interaction lookup", "Customer query log"] },
            { role: "Admins", color: "from-violet-500 to-fuchsia-500", points: ["Real-time analytics dashboard", "Manage medicine database", "Manage users & roles", "Full audit trail"] },
          ].map((r) => (
            <div key={r.role} className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
              <div className={`h-24 bg-gradient-to-br ${r.color} flex items-end p-5`}>
                <h3 className="text-2xl font-bold text-white">For {r.role}</h3>
              </div>
              <ul className="p-6 space-y-3 text-sm">
                {r.points.map((p) => (
                  <li key={p} className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
                    <span className="text-brand-500">✓</span>{p}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Safety */}
      <section id="safety" className="py-20 bg-gradient-to-br from-brand-500 to-cyan-600 text-white">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold">Safety by default</h2>
          <p className="mt-4 text-lg text-cyan-50 max-w-2xl mx-auto">
            MediBot never diagnoses or prescribes. Every response shows a medical disclaimer and points to a qualified professional. Emergencies trigger immediate guidance to call local emergency services.
          </p>
          <div className="flex flex-wrap justify-center gap-3 mt-8">
            <Button size="lg" variant="secondary" onClick={() => setPage("register")}>Create account</Button>
            <Button size="lg" variant="outline" className="!bg-white/10 !border-white/40 !text-white hover:!bg-white/20" onClick={() => setPage("login")}>Sign in</Button>
          </div>
        </div>
      </section>

      <footer className="py-10 border-t border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <MediBotLogo />
          <p className="text-sm text-slate-500">© 2026 MediBot Health Inc. For informational purposes only.</p>
        </div>
      </footer>
    </div>
  );
}
