import { useMemo, useState } from "react";
import { useApp } from "../store";
import { MedicineCard } from "../components/MedicineCard";
import { Card, Input, Select, Badge } from "../components/ui";
import type { Medicine } from "../types";
import { rankMedicines } from "../lib/ai";

export function Search({ onOpen, advanced = false }: { onOpen: (m: Medicine) => void; advanced?: boolean }) {
  const { medicines } = useApp();
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("all");
  const [form, setForm] = useState("all");
  const [rx, setRx] = useState("all");
  const [sort, setSort] = useState("popular");

  const categories = useMemo(() => Array.from(new Set(medicines.map((m) => m.category))).sort(), [medicines]);
  const forms = useMemo(() => Array.from(new Set(medicines.map((m) => m.form))).sort(), [medicines]);

  const filtered = useMemo(() => {
    let list = medicines;
    if (q.trim()) {
      const ranked = rankMedicines(q, list, 100);
      list = ranked.length ? ranked : list.filter((m) =>
        [m.name, m.brand, m.generic, m.category].join(" ").toLowerCase().includes(q.toLowerCase())
      );
    }
    if (category !== "all") list = list.filter((m) => m.category === category);
    if (form !== "all") list = list.filter((m) => m.form === form);
    if (rx === "rx") list = list.filter((m) => m.prescription);
    if (rx === "otc") list = list.filter((m) => !m.prescription);
    if (sort === "popular") list = [...list].sort((a, b) => b.searches - a.searches);
    if (sort === "az") list = [...list].sort((a, b) => a.brand.localeCompare(b.brand));
    return list;
  }, [medicines, q, category, form, rx, sort]);

  return (
    <div className="p-4 lg:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{advanced ? "Advanced Medicine Search" : "Search Medicines"}</h1>
        <p className="text-slate-500 mt-1 text-sm">{advanced ? "Filter by category, form, prescription status and more." : "Find approved medicine information instantly."}</p>
      </div>

      <Card className="p-4 lg:p-5">
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="relative flex-1">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name, brand, generic, manufacturer…" className="!pl-10" />
          </div>
          <Select value={category} onChange={(e) => setCategory(e.target.value)}>
            <option value="all">All categories</option>
            {categories.map((c) => <option key={c} value={c}>{c}</option>)}
          </Select>
          <Select value={form} onChange={(e) => setForm(e.target.value)}>
            <option value="all">All forms</option>
            {forms.map((f) => <option key={f} value={f}>{f}</option>)}
          </Select>
          {advanced && (
            <Select value={rx} onChange={(e) => setRx(e.target.value)}>
              <option value="all">All types</option>
              <option value="rx">Prescription only</option>
              <option value="otc">Over-the-counter</option>
            </Select>
          )}
          <Select value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="popular">Most popular</option>
            <option value="az">A → Z</option>
          </Select>
        </div>
        <div className="mt-3 flex items-center justify-between text-sm text-slate-500">
          <span>{filtered.length} {filtered.length === 1 ? "result" : "results"}</span>
          {(q || category !== "all" || form !== "all" || rx !== "all") && (
            <button onClick={() => { setQ(""); setCategory("all"); setForm("all"); setRx("all"); }} className="text-brand-600 hover:underline">Clear filters</button>
          )}
        </div>
      </Card>

      {advanced && (
        <Card className="p-4">
          <p className="text-sm font-medium mb-2">Popular categories</p>
          <div className="flex flex-wrap gap-2">
            {categories.slice(0, 8).map((c) => (
              <button key={c} onClick={() => setCategory(c)}>
                <Badge color={category === c ? "brand" : "slate"}>{c}</Badge>
              </button>
            ))}
          </div>
        </Card>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {filtered.map((m) => <MedicineCard key={m.id} m={m} onOpen={onOpen} />)}
        {filtered.length === 0 && (
          <Card className="col-span-full p-10 text-center text-slate-500">
            <div className="text-4xl mb-2">🔎</div>
            No medicines match your search.
          </Card>
        )}
      </div>
    </div>
  );
}
