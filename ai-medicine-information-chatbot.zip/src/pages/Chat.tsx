import { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "../store";
import { Button, Disclaimer } from "../components/ui";
import { Markdown } from "../components/Markdown";
import { FAQ_SUGGESTIONS, generateAIResponse } from "../lib/ai";
import type { ChatMessage, ChatSession } from "../types";
import { cn } from "../utils/cn";

export function Chat({ activeChatId, setActiveChatId }: { activeChatId: string | null; setActiveChatId: (id: string | null) => void }) {
  const { currentUser, medicines, chats, addChat, updateChat, deleteChat, bumpSearch } = useApp();
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [listening, setListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const userChats = useMemo(
    () => chats.filter((c) => c.userId === currentUser?.id),
    [chats, currentUser]
  );

  const active = useMemo(
    () => userChats.find((c) => c.id === activeChatId) || null,
    [userChats, activeChatId]
  );

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [active?.messages.length, thinking]);

  const startNewChat = (firstQuery?: string) => {
    if (!currentUser) return null;
    const id = `chat-${Date.now()}`;
    const session: ChatSession = {
      id,
      userId: currentUser.id,
      title: firstQuery ? firstQuery.slice(0, 48) : "New chat",
      createdAt: Date.now(),
      messages: [
        {
          id: `m-${Date.now()}`,
          role: "bot",
          ts: Date.now(),
          text:
            `👋 Hi **${currentUser.name.split(" ")[0]}**, I'm **MediBot**. Ask me anything about your medicines — uses, dosage, side effects, storage, or interactions.\n\nWhat can I help you with today?`,
        },
      ],
    };
    addChat(session);
    setActiveChatId(id);
    return session;
  };

  const send = async (raw?: string) => {
    const text = (raw ?? input).trim();
    if (!text || !currentUser) return;
    setInput("");

    let session = active;
    if (!session) {
      session = startNewChat(text);
      if (!session) return;
    }

    const userMsg: ChatMessage = { id: `m-${Date.now()}`, role: "user", text, ts: Date.now() };
    const updatedTitle = session.messages.length <= 1 ? text.slice(0, 48) : session.title;
    updateChat(session.id, { messages: [...session.messages, userMsg], title: updatedTitle });

    setThinking(true);
    await new Promise((r) => setTimeout(r, 700 + Math.random() * 500));
    const ai = generateAIResponse(text, medicines);
    ai.medicineRefs.forEach(bumpSearch);

    const botMsg: ChatMessage = {
      id: `m-${Date.now() + 1}`,
      role: "bot",
      text: ai.text,
      ts: Date.now(),
      medicineRefs: ai.medicineRefs,
      disclaimer: true,
    };
    updateChat(session.id, { messages: [...session.messages, userMsg, botMsg] });
    setThinking(false);
  };

  const startVoice = () => {
    const SR = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    if (!SR) { alert("Voice input not supported in this browser."); return; }
    const r = new SR();
    r.lang = "en-US"; r.interimResults = false;
    r.onstart = () => setListening(true);
    r.onend = () => setListening(false);
    r.onresult = (e: any) => { setInput(e.results[0][0].transcript); inputRef.current?.focus(); };
    r.start();
  };

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Sessions */}
      <aside className="hidden md:flex flex-col w-72 shrink-0 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/50">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800">
          <Button className="w-full" onClick={() => startNewChat()}>+ New chat</Button>
        </div>
        <div className="flex-1 overflow-y-auto thin-scroll p-2 space-y-1">
          {userChats.length === 0 && (
            <p className="text-center text-xs text-slate-500 py-8">No conversations yet</p>
          )}
          {userChats.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveChatId(c.id)}
              className={cn(
                "w-full text-left px-3 py-2.5 rounded-lg group transition",
                c.id === activeChatId
                  ? "bg-brand-50 dark:bg-brand-900/30 text-brand-800 dark:text-brand-200"
                  : "hover:bg-slate-100 dark:hover:bg-slate-800/60 text-slate-700 dark:text-slate-300"
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-medium truncate flex-1">{c.title}</p>
                <span
                  onClick={(e) => { e.stopPropagation(); if (confirm("Delete this conversation?")) { deleteChat(c.id); if (activeChatId === c.id) setActiveChatId(null); } }}
                  className="opacity-0 group-hover:opacity-100 text-xs text-slate-400 hover:text-rose-500 cursor-pointer"
                >🗑</span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">{new Date(c.createdAt).toLocaleDateString()} · {c.messages.length} msgs</p>
            </button>
          ))}
        </div>
      </aside>

      {/* Chat panel */}
      <div className="flex-1 flex flex-col min-w-0 bg-slate-50 dark:bg-slate-950">
        {!active ? (
          <div className="flex-1 flex items-center justify-center p-6">
            <div className="max-w-2xl text-center space-y-6">
              <div className="inline-flex h-16 w-16 rounded-2xl bg-gradient-to-br from-brand-500 to-cyan-500 items-center justify-center text-3xl shadow-lg shadow-cyan-500/30">🤖</div>
              <div>
                <h2 className="text-2xl font-bold">How can I help you today?</h2>
                <p className="text-slate-500 mt-2">Ask about any medicine in our approved database.</p>
              </div>
              <div className="grid sm:grid-cols-2 gap-3 text-left">
                {FAQ_SUGGESTIONS.map((q) => (
                  <button key={q} onClick={() => send(q)}
                    className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-brand-400 dark:hover:border-brand-500 hover:shadow-md transition text-sm">
                    <span className="text-brand-500 mr-2">💬</span>{q}
                  </button>
                ))}
              </div>
              <Disclaimer compact />
            </div>
          </div>
        ) : (
          <div ref={scrollRef} className="flex-1 overflow-y-auto thin-scroll px-4 lg:px-8 py-6">
            <div className="max-w-3xl mx-auto space-y-5">
              {active.messages.map((m) => (
                <MessageBubble key={m.id} m={m} medicines={medicines} />
              ))}
              {thinking && (
                <div className="flex gap-3 animate-fade-up">
                  <div className="h-9 w-9 rounded-full bg-gradient-to-br from-brand-500 to-cyan-500 flex items-center justify-center text-white shrink-0">🤖</div>
                  <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm">
                    <div className="flex items-center gap-1">
                      <span className="dot h-2 w-2 rounded-full bg-brand-500" />
                      <span className="dot h-2 w-2 rounded-full bg-brand-500" />
                      <span className="dot h-2 w-2 rounded-full bg-brand-500" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Composer */}
        <div className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
          <div className="max-w-3xl mx-auto">
            <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2 items-center">
              <Button type="button" variant="outline" size="icon" onClick={startVoice} title="Voice input" className={listening ? "!bg-rose-50 !border-rose-400 !text-rose-600" : ""}>
                {listening ? "🔴" : "🎤"}
              </Button>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about a medicine, dosage, side effects…"
                className="flex-1 h-11 px-4 rounded-xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500/50 focus:border-brand-500/50 transition"
              />
              <Button type="submit" disabled={!input.trim() || thinking}>Send →</Button>
            </form>
            <p className="text-[11px] text-slate-400 text-center mt-2">
              MediBot can make mistakes — always consult a qualified healthcare professional.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function MessageBubble({ m, medicines }: { m: ChatMessage; medicines: any[] }) {
  if (m.role === "user") {
    return (
      <div className="flex justify-end animate-fade-up">
        <div className="max-w-[85%] bg-gradient-to-r from-brand-500 to-cyan-500 text-white rounded-2xl rounded-tr-sm px-4 py-2.5 shadow">
          {m.text}
        </div>
      </div>
    );
  }
  const refs = (m.medicineRefs || []).map((id) => medicines.find((x) => x.id === id)).filter(Boolean);
  return (
    <div className="flex gap-3 animate-fade-up">
      <div className="h-9 w-9 rounded-full bg-gradient-to-br from-brand-500 to-cyan-500 flex items-center justify-center text-white shrink-0">🤖</div>
      <div className="flex-1 min-w-0">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm text-sm">
          <Markdown source={m.text} />
          {refs.length > 0 && (
            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-2">
              {refs.map((r: any) => (
                <span key={r.id} className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-brand-50 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 text-xs">
                  <span>{r.image}</span>{r.brand}
                </span>
              ))}
            </div>
          )}
        </div>
        {m.disclaimer && <div className="mt-2"><Disclaimer compact /></div>}
        <p className="text-[11px] text-slate-400 mt-1">{new Date(m.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
      </div>
    </div>
  );
}
