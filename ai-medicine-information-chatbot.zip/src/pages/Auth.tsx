import { useState } from "react";
import { Button, Card, Input, Select } from "../components/ui";
import { MediBotLogo, type PageKey } from "../components/Layout";
import { useApp } from "../store";
import type { Role } from "../types";

export function Auth({ mode, setPage }: { mode: "login" | "register"; setPage: (p: PageKey) => void }) {
  const { login, register } = useApp();
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "customer" as Role });
  const [error, setError] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    const res = mode === "login"
      ? login(form.email, form.password)
      : register(form.name, form.email, form.password, form.role);
    if (!res.ok) setError(res.error || "Something went wrong.");
  };

  const fillDemo = (role: Role) => {
    const creds = {
      customer: { email: "patient@medibot.health", password: "patient123" },
      pharmacist: { email: "pharmacist@medibot.health", password: "pharma123" },
      admin: { email: "admin@medibot.health", password: "admin123" },
    }[role];
    setForm((f) => ({ ...f, ...creds }));
  };

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-950">
      <div className="hidden lg:flex flex-col justify-between p-12 w-1/2 bg-gradient-to-br from-brand-600 via-cyan-600 to-teal-600 text-white relative overflow-hidden">
        <div className="absolute inset-0 grid-bg opacity-30" />
        <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-white/10 blur-3xl" />
        <button onClick={() => setPage("landing")} className="relative">
          <MediBotLogo />
        </button>
        <div className="relative space-y-6 max-w-md">
          <h2 className="text-4xl font-bold leading-tight">Medicine information your team can actually trust.</h2>
          <p className="text-cyan-50">
            MediBot delivers answers grounded in your approved product database — never invented, always safe.
          </p>
          <div className="space-y-3">
            {["Built-in medical disclaimers", "Role-based access control", "Vector-search medicine knowledge base", "Full audit trail"].map((p) => (
              <div key={p} className="flex items-center gap-3 text-cyan-50">
                <span className="h-6 w-6 rounded-full bg-white/20 flex items-center justify-center text-sm">✓</span>
                {p}
              </div>
            ))}
          </div>
        </div>
        <p className="relative text-sm text-cyan-100">© 2026 MediBot Health Inc.</p>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md">
          <button onClick={() => setPage("landing")} className="lg:hidden mb-6 flex justify-center w-full">
            <MediBotLogo />
          </button>
          <Card className="p-8">
            <h1 className="text-2xl font-bold mb-1">{mode === "login" ? "Welcome back" : "Create your account"}</h1>
            <p className="text-sm text-slate-500 mb-6">
              {mode === "login" ? "Sign in to access your MediBot portal." : "Choose a role to get started in seconds."}
            </p>

            {mode === "login" && (
              <div className="mb-5 p-3 rounded-xl bg-brand-50 dark:bg-brand-900/20 border border-brand-200 dark:border-brand-800/50">
                <p className="text-xs font-medium text-brand-800 dark:text-brand-200 mb-2">Try a demo account:</p>
                <div className="grid grid-cols-3 gap-2">
                  {(["customer", "pharmacist", "admin"] as Role[]).map((r) => (
                    <button key={r} onClick={() => fillDemo(r)}
                      className="text-xs px-2 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-brand-200 dark:border-brand-800/40 capitalize hover:bg-brand-100 dark:hover:bg-brand-900/40 transition">
                      {r}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <form onSubmit={submit} className="space-y-4">
              {mode === "register" && (
                <div>
                  <label className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5 block">Full name</label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Dr. Jane Doe" required />
                </div>
              )}
              <div>
                <label className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5 block">Email address</label>
                <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" required />
              </div>
              <div>
                <label className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5 block">Password</label>
                <Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••" required />
              </div>
              {mode === "register" && (
                <div>
                  <label className="text-xs font-medium text-slate-600 dark:text-slate-300 mb-1.5 block">I am a</label>
                  <Select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as Role })} className="w-full">
                    <option value="customer">Patient / Customer</option>
                    <option value="pharmacist">Pharmacist</option>
                    <option value="admin">Administrator</option>
                  </Select>
                </div>
              )}

              {error && <p className="text-sm text-rose-600 bg-rose-50 dark:bg-rose-900/20 px-3 py-2 rounded-lg">{error}</p>}

              <Button type="submit" size="lg" className="w-full">
                {mode === "login" ? "Sign in" : "Create account"}
              </Button>
            </form>

            <p className="text-sm text-center mt-6 text-slate-500">
              {mode === "login" ? "Don't have an account? " : "Already have an account? "}
              <button onClick={() => setPage(mode === "login" ? "register" : "login")} className="text-brand-600 font-medium hover:underline">
                {mode === "login" ? "Sign up" : "Sign in"}
              </button>
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
