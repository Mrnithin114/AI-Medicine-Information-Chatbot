import { useMemo } from "react";
import { useApp } from "../store";
import { Button, Card } from "../components/ui";
import { Markdown } from "../components/Markdown";
import type { PageKey } from "../components/Layout";

export function History({ setPage, openChat }: { setPage: (p: PageKey) => void; openChat: (id: string) => void }) {
  const { currentUser, chats, deleteChat } = useApp();
  const my = useMemo(() => chats.filter((c) => c.userId === currentUser?.id), [chats, currentUser]);

  return (
    <div className="p-4 lg:p-8 max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Chat History</h1>
          <p className="text-slate-500 text-sm mt-1">All your past conversations with MediBot.</p>
        </div>
        <Button onClick={() => setPage("chat")}>+ New chat</Button>
      </div>

      {my.length === 0 && (
        <Card className="p-12 text-center text-slate-500">
          <div className="text-5xl mb-3">💬</div>
          <p className="font-medium text-slate-700 dark:text-slate-300">No conversations yet</p>
          <p className="text-sm mt-1">Start a chat with MediBot to see your history here.</p>
        </Card>
      )}

      <div className="space-y-3">
        {my.map((c) => {
          const last = c.messages[c.messages.length - 1];
          return (
            <Card key={c.id} className="p-5 hover:shadow-md transition group">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0 cursor-pointer" onClick={() => openChat(c.id)}>
                  <h3 className="font-semibold truncate">{c.title}</h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {new Date(c.createdAt).toLocaleString()} · {c.messages.length} messages
                  </p>
                  <div className="mt-2 text-sm text-slate-600 dark:text-slate-300 line-clamp-2 italic">
                    <Markdown source={last?.text.slice(0, 200) || ""} />
                  </div>
                </div>
                <div className="flex flex-col gap-2 shrink-0">
                  <Button size="sm" variant="outline" onClick={() => openChat(c.id)}>Open</Button>
                  <Button size="sm" variant="ghost" onClick={() => { if (confirm("Delete?")) deleteChat(c.id); }} className="!text-rose-600">Delete</Button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
