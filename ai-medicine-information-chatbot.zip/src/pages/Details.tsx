import { Badge, Button, Card, Disclaimer } from "../components/ui";
import { useApp } from "../store";
import type { Medicine } from "../types";

export function Details({ medicine, onBack }: { medicine: Medicine; onBack: () => void }) {
  const { currentUser, toggleFavorite } = useApp();
  const isFav = currentUser?.favorites.includes(medicine.id);

  const downloadInfo = () => {
    const txt = buildInfoSheet(medicine);
    const blob = new Blob([txt], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${medicine.brand}_info_sheet.txt`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-4 lg:p-8 max-w-5xl mx-auto space-y-6">
      <button onClick={onBack} className="text-sm text-brand-600 hover:underline">← Back</button>

      <Card className="overflow-hidden">
        <div className={`h-44 bg-gradient-to-br ${medicine.color} flex items-center justify-center relative`}>
          <span className="text-7xl drop-shadow-lg">{medicine.image}</span>
          {medicine.prescription && (
            <span className="absolute top-4 left-4 text-xs uppercase font-bold px-3 py-1 rounded-full bg-rose-600 text-white">Prescription only</span>
          )}
        </div>
        <div className="p-6 lg:p-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold">{medicine.brand}</h1>
              <p className="text-slate-500 mt-1">{medicine.generic} • {medicine.manufacturer}</p>
              <div className="flex flex-wrap gap-2 mt-3">
                <Badge color="brand">{medicine.category}</Badge>
                <Badge color="slate">{medicine.form}</Badge>
                <Badge color="slate">{medicine.strength}</Badge>
                <Badge color="violet">🔍 {medicine.searches} searches</Badge>
              </div>
            </div>
            <div className="flex gap-2">
              {currentUser && (
                <Button variant="outline" onClick={() => toggleFavorite(medicine.id)}>
                  {isFav ? "♥ Saved" : "♡ Save"}
                </Button>
              )}
              <Button onClick={downloadInfo}>⬇ Info sheet</Button>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Section title="📋 Composition" body={medicine.composition} />
            <Section title="💡 Uses" list={medicine.uses} />
            <Section title="📖 Directions for Use" body={medicine.directions} />
            <Section title="📦 Storage Instructions" body={medicine.storage} />
            <Section title="⚠️ Side Effects" list={medicine.sideEffects} accent="amber" />
            <Section title="🚫 Contraindications" list={medicine.contraindications} accent="rose" />
            <Section title="🔄 Drug Interactions" list={medicine.interactions} accent="amber" />
            <Section title="🛡️ Warnings & Precautions" list={medicine.warnings} accent="rose" />
          </div>

          <div className="mt-6">
            <Disclaimer />
          </div>
        </div>
      </Card>
    </div>
  );
}

function Section({ title, body, list, accent }: { title: string; body?: string; list?: string[]; accent?: "amber" | "rose" }) {
  const ring = accent === "amber" ? "border-amber-200 dark:border-amber-800/50 bg-amber-50/40 dark:bg-amber-900/10"
              : accent === "rose" ? "border-rose-200 dark:border-rose-800/50 bg-rose-50/40 dark:bg-rose-900/10"
              : "border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40";
  return (
    <div className={`rounded-xl border ${ring} p-4`}>
      <h3 className="font-semibold mb-2">{title}</h3>
      {body && <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">{body}</p>}
      {list && (
        <ul className="space-y-1 text-sm text-slate-700 dark:text-slate-300">
          {list.map((x, i) => <li key={i} className="flex gap-2"><span className="text-brand-500">•</span><span>{x}</span></li>)}
        </ul>
      )}
    </div>
  );
}

function buildInfoSheet(m: Medicine): string {
  return `MEDICINE INFORMATION SHEET
================================================
Brand:         ${m.brand}
Generic:       ${m.generic}
Manufacturer:  ${m.manufacturer}
Category:      ${m.category}
Form:          ${m.form} (${m.strength})
Composition:   ${m.composition}
Prescription:  ${m.prescription ? "Yes" : "No"}

USES
${m.uses.map((u) => `  • ${u}`).join("\n")}

DIRECTIONS FOR USE
  ${m.directions}

SIDE EFFECTS
${m.sideEffects.map((s) => `  • ${s}`).join("\n")}

CONTRAINDICATIONS
${m.contraindications.map((c) => `  • ${c}`).join("\n")}

DRUG INTERACTIONS
${m.interactions.map((i) => `  • ${i}`).join("\n")}

WARNINGS & PRECAUTIONS
${m.warnings.map((w) => `  ! ${w}`).join("\n")}

STORAGE INSTRUCTIONS
  ${m.storage}

================================================
DISCLAIMER:
This information is for educational purposes only and does not
replace professional medical advice, diagnosis or treatment.
Always consult your physician or pharmacist before starting any
medication. For emergencies call your local emergency number.

Generated by MediBot · ${new Date().toLocaleString()}
`;
}
