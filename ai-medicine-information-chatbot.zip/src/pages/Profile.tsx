import { useApp } from "../store";
import { Badge, Button, Card } from "../components/ui";

export function Profile() {
  const { currentUser, chats, medicines, logout } = useApp();
  if (!currentUser) return null;
  const my = chats.filter((c) => c.userId === currentUser.id);
  const queryCount = my.reduce((a, c) => a + c.messages.filter((m) => m.role === "user").length, 0);
  const favCount = currentUser.favorites.length;
  const memberDays = Math.max(1, Math.round((Date.now() - currentUser.createdAt) / 86400_000));

  return (
    <div className="p-4 lg:p-8 max-w-4xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">My Profile</h1>

      <Card className="p-6">
        <div className="flex flex-col sm:flex-row gap-6 items-center sm:items-start">
          <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-brand-500 to-cyan-500 text-white text-3xl font-bold flex items-center justify-center shadow-lg shadow-cyan-500/30">
            {currentUser.name.charAt(0)}
          </div>
          <div className="flex-1 text-center sm:text-left">
            <h2 className="text-xl font-bold">{currentUser.name}</h2>
            <p className="text-sm text-slate-500">{currentUser.email}</p>
            <div className="mt-2 flex flex-wrap justify-center sm:justify-start gap-2">
              <Badge color="brand">{currentUser.role}</Badge>
              <Badge color="green">Member for {memberDays}d</Badge>
            </div>
          </div>
          <Button variant="outline" onClick={logout}>Sign out</Button>
        </div>
      </Card>

      <div className="grid sm:grid-cols-3 gap-4">
        <Stat label="Conversations" value={my.length} icon="💬" />
        <Stat label="Questions asked" value={queryCount} icon="❓" />
        <Stat label="Saved medicines" value={favCount} icon="♥" />
      </div>

      <Card className="p-6">
        <h3 className="font-semibold mb-3">My recent favorites</h3>
        {favCount === 0 ? (
          <p className="text-sm text-slate-500">No favorites yet.</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {currentUser.favorites.map((id) => {
              const m = medicines.find((x) => x.id === id);
              if (!m) return null;
              return <Badge key={id} color="slate">{m.image} {m.brand}</Badge>;
            })}
          </div>
        )}
      </Card>

      <Card className="p-6">
        <h3 className="font-semibold mb-3">Notification preferences</h3>
        <div className="space-y-3">
          {["Email me chat summaries", "New medicine alerts in my favorites", "Weekly health insights"].map((p) => (
            <label key={p} className="flex items-center gap-3 text-sm cursor-pointer">
              <input type="checkbox" defaultChecked className="h-4 w-4 rounded text-brand-500 focus:ring-brand-400" />
              {p}
            </label>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: number; icon: string }) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-slate-500 uppercase tracking-wide">{label}</p>
          <p className="text-3xl font-bold mt-1 tabular-nums">{value}</p>
        </div>
        <div className="h-12 w-12 rounded-xl bg-brand-50 dark:bg-brand-900/30 flex items-center justify-center text-2xl">{icon}</div>
      </div>
    </Card>
  );
}
