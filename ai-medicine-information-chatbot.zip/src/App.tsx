import { useEffect, useState } from "react";
import { AppProvider, useApp } from "./store";
import { AppShell, type PageKey } from "./components/Layout";
import { Landing } from "./pages/Landing";
import { Auth } from "./pages/Auth";
import { Chat } from "./pages/Chat";
import { Search } from "./pages/Search";
import { Details } from "./pages/Details";
import { History } from "./pages/History";
import { Favorites } from "./pages/Favorites";
import { Profile } from "./pages/Profile";
import { Compare, Interactions, Queries } from "./pages/Pharmacist";
import { Dashboard, Logs, MedicinesAdmin, Reports, UsersAdmin } from "./pages/Admin";
import type { Medicine } from "./types";

function Router() {
  const { currentUser } = useApp();
  const [page, setPage] = useState<PageKey>("landing");
  const [detailMed, setDetailMed] = useState<Medicine | null>(null);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);

  // when user logs in/out, jump to sensible default
  useEffect(() => {
    if (currentUser) {
      setPage(currentUser.role === "admin" ? "admin-dash" : "chat");
    } else {
      setPage("landing");
    }
  }, [currentUser?.id]); // eslint-disable-line

  // public routes
  if (!currentUser) {
    if (page === "login" || page === "register") return <Auth mode={page} setPage={setPage} />;
    return <Landing setPage={setPage} />;
  }

  const openMed = (m: Medicine) => { setDetailMed(m); setPage("details"); };
  const openChat = (id: string) => { setActiveChatId(id); setPage("chat"); };

  let content: React.ReactNode = null;
  switch (page) {
    case "chat":
      content = <Chat activeChatId={activeChatId} setActiveChatId={setActiveChatId} />; break;
    case "search":
      content = <Search onOpen={openMed} />; break;
    case "details":
      content = detailMed ? <Details medicine={detailMed} onBack={() => setPage("search")} /> : <Search onOpen={openMed} />; break;
    case "history":
      content = <History setPage={setPage} openChat={openChat} />; break;
    case "favorites":
      content = <Favorites onOpen={openMed} />; break;
    case "profile":
      content = <Profile />; break;
    case "pharm-search":
      content = <Search onOpen={openMed} advanced />; break;
    case "pharm-compare":
      content = <Compare />; break;
    case "pharm-interactions":
      content = <Interactions />; break;
    case "pharm-queries":
      content = <Queries />; break;
    case "admin-dash":
      content = <Dashboard />; break;
    case "admin-meds":
      content = <MedicinesAdmin />; break;
    case "admin-users":
      content = <UsersAdmin />; break;
    case "admin-reports":
      content = <Reports />; break;
    case "admin-logs":
      content = <Logs />; break;
    default:
      content = currentUser.role === "admin" ? <Dashboard /> : <Chat activeChatId={activeChatId} setActiveChatId={setActiveChatId} />;
  }

  return <AppShell page={page} setPage={setPage}>{content}</AppShell>;
}

export default function App() {
  return (
    <AppProvider>
      <Router />
    </AppProvider>
  );
}
