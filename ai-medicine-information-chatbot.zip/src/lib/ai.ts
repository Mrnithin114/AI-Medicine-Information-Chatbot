import type { Medicine } from "../types";

/**
 * Lightweight on-device "AI" engine.
 * - Tokenises the question
 * - Scores medicines by token overlap with name/brand/generic/uses/category
 * - Detects intent (usage, dosage, side effects, storage, interaction, warnings, compare, emergency)
 * - Formats a structured, safety-conscious response
 */

const STOPWORDS = new Set([
  "a","an","the","is","of","for","to","do","does","what","how","when","why","can","i","my","me","mg","tab","tablet","tablets","pill","pills","use","used","take","taking","with","and","or","on","in","about","tell","please","know","need","want","this","that","it","its","be","are","was","were","you","your","there","their","they","them","over","under","without","should","could","would","may","might","than","then","also","so","not","no","yes","please","thanks","thank","hi","hello","hey",
]);

export function tokenize(s: string) {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t && !STOPWORDS.has(t));
}

export function rankMedicines(query: string, medicines: Medicine[], limit = 5) {
  const q = tokenize(query);
  if (!q.length) return [];
  const scored = medicines.map((m) => {
    const haystack = [
      m.name, m.brand, m.generic, m.category, m.composition,
      m.uses.join(" "), m.form, m.manufacturer,
    ].join(" ").toLowerCase();
    let score = 0;
    for (const t of q) {
      if (haystack.includes(t)) score += 2;
      if (m.name.toLowerCase().includes(t)) score += 3;
      if (m.brand.toLowerCase().includes(t)) score += 3;
      if (m.generic.toLowerCase().includes(t)) score += 3;
    }
    return { m, score };
  });
  return scored.filter((x) => x.score > 0).sort((a, b) => b.score - a.score).slice(0, limit).map((x) => x.m);
}

type Intent = "usage" | "dosage" | "side_effects" | "storage" | "interactions" | "warnings" | "compare" | "emergency" | "info" | "greeting";

export function detectIntent(query: string): Intent {
  const q = query.toLowerCase();
  if (/(emergency|overdose|severe|unconscious|chest pain|bleeding|call 911|allergic shock|anaphyl)/.test(q)) return "emergency";
  if (/(hi|hello|hey|good (morning|evening))\b/.test(q.trim())) return "greeting";
  if (/(vs|versus|compare|difference between)/.test(q)) return "compare";
  if (/(side ?effect|adverse|reaction)/.test(q)) return "side_effects";
  if (/(dose|dosage|how much|how many|how often|frequency|directions|how to take)/.test(q)) return "dosage";
  if (/(storage|store|keep|fridge|refrigerate|temperature)/.test(q)) return "storage";
  if (/(interaction|interact|together with|along with|combined)/.test(q)) return "interactions";
  if (/(warning|precaution|safe|safety|contraindication|avoid)/.test(q)) return "warnings";
  if (/(use|used for|treat|good for|purpose|indication|what is)/.test(q)) return "usage";
  return "info";
}

export interface AIResponse {
  text: string;
  medicineRefs: string[];
  isEmergency?: boolean;
}

export function generateAIResponse(query: string, medicines: Medicine[]): AIResponse {
  const intent = detectIntent(query);

  if (intent === "greeting") {
    return {
      text:
        "Hello! 👋 I'm **MediBot**, your AI medicine information assistant.\n\nYou can ask me things like:\n• *\"What is Paracetamol used for?\"*\n• *\"What is the dosage of Amoxicillin?\"*\n• *\"Side effects of Atorvastatin\"*\n• *\"Compare Cetirizine vs Loratadine\"*\n\nI provide information from our approved medicine database — but I'm not a substitute for a doctor or pharmacist.",
      medicineRefs: [],
    };
  }

  if (intent === "emergency") {
    return {
      text:
        "🚨 **This sounds like a medical emergency.**\n\nPlease **call your local emergency number (e.g. 911 / 999 / 112) immediately**, or go to the nearest emergency department.\n\nI'm an information assistant and **cannot help with active medical emergencies**. If someone has taken an overdose, also contact your national Poison Control Centre.",
      medicineRefs: [],
      isEmergency: true,
    };
  }

  const matches = rankMedicines(query, medicines, 3);

  if (intent === "compare" && matches.length >= 2) {
    const [a, b] = matches;
    const txt =
`### Comparison: ${a.brand} vs ${b.brand}

| Attribute | **${a.brand}** | **${b.brand}** |
|---|---|---|
| Generic | ${a.generic} | ${b.generic} |
| Category | ${a.category} | ${b.category} |
| Form | ${a.form} | ${b.form} |
| Strength | ${a.strength} | ${b.strength} |
| Prescription? | ${a.prescription ? "Yes" : "No"} | ${b.prescription ? "Yes" : "No"} |

**Primary uses**
- **${a.brand}:** ${a.uses.slice(0, 2).join(", ")}
- **${b.brand}:** ${b.uses.slice(0, 2).join(", ")}

ℹ️ A pharmacist can help you choose the option best suited to your situation.`;
    return { text: txt, medicineRefs: [a.id, b.id] };
  }

  if (!matches.length) {
    return {
      text:
`I couldn't find a matching medicine in our approved database for *"${query}"*.

Try searching by **brand name** (e.g. "Calpol"), **generic name** (e.g. "Paracetamol"), or **category** (e.g. "Antibiotic"). You can also browse the **Medicine Search** page.

If you have a specific medical concern, please consult a qualified pharmacist or physician.`,
      medicineRefs: [],
    };
  }

  const m = matches[0];

  let body = "";
  switch (intent) {
    case "usage":
      body = `**${m.brand} (${m.generic})** is primarily used for:\n\n${m.uses.map((u) => `• ${u}`).join("\n")}\n\n**Category:** ${m.category}\n**Form:** ${m.form} — **Strength:** ${m.strength}`;
      break;
    case "dosage":
      body = `**Recommended directions for ${m.brand} (${m.strength}):**\n\n> ${m.directions}\n\nAlways follow the dose prescribed by your physician or shown on the product label.`;
      break;
    case "side_effects":
      body = `**Reported side effects of ${m.brand}:**\n\n${m.sideEffects.map((s) => `• ${s}`).join("\n")}\n\nIf you experience severe or persistent symptoms, stop the medicine and consult a doctor.`;
      break;
    case "storage":
      body = `**Storage instructions for ${m.brand}:**\n\n> ${m.storage}`;
      break;
    case "interactions":
      body = `**Known interactions for ${m.brand}:**\n\n${m.interactions.map((i) => `• ${i}`).join("\n")}\n\nAlways tell your pharmacist about every medicine and supplement you take.`;
      break;
    case "warnings":
      body = `**Warnings & precautions for ${m.brand}:**\n\n${m.warnings.map((w) => `⚠️ ${w}`).join("\n")}\n\n**Contraindications:**\n${m.contraindications.map((c) => `• ${c}`).join("\n")}`;
      break;
    default:
      body =
`### ${m.brand} — ${m.generic}
**Manufacturer:** ${m.manufacturer}  •  **Category:** ${m.category}  •  **Form:** ${m.form} ${m.strength}

**Used for:** ${m.uses.slice(0, 3).join(", ")}

**Directions:** ${m.directions}

**Common side effects:** ${m.sideEffects.slice(0, 3).join(", ")}`;
  }

  const related = matches.slice(1).map((x) => `• ${x.brand} (${x.generic})`).join("\n");
  if (related) body += `\n\n**Related medicines you might be interested in:**\n${related}`;

  return { text: body, medicineRefs: matches.map((x) => x.id) };
}

export const FAQ_SUGGESTIONS = [
  "What is Paracetamol used for?",
  "Dosage of Amoxicillin 500mg",
  "Side effects of Atorvastatin",
  "How should I store Insulin Glargine?",
  "Compare Cetirizine vs Loratadine",
  "Can I take Ibuprofen with Aspirin?",
];
