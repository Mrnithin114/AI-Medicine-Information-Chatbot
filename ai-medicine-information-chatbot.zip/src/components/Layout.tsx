import { type ReactNode, useState } from "react";
import { useApp } from "../store";
import { cn } from "../utils/cn";
import { Button } from "./ui";

export type PageKey =
  | "landing" | "login" | "register"
  | "chat" | "search" | "details" | "history" | "favorites" | "profile"
  | "pharm-search" | "pharm-compare" | "pharm-interactions" | "pharm-queries"
  | "admin-dash" | "admin-meds" | "admin-users" | "admin-reports" | "admin-logs";

export interface NavItem { key: PageKey; label: string; icon: string; }

const ROLE_NAV: Record<string, NavItem[]> = {
  customer: [
    { key: "chat", label: "AI Chatbot", icon: "💬" },
    { key: "search", label: "Search Medicines", icon: "🔍" },
    { key: "favorites", label: "Favorites", icon: "♥" },
    { key: "history", label: "Chat History", icon: "🕐" },
    { key: "profile", label: "My Profile", icon: "👤" },
  ],
  pharmacist: [
    { key: "chat", label: "AI Assistant", icon: "💬" },
    { key: "pharm-search", label: "Advanced Search", icon: "🔬" },
    { key: "pharm-compare", label: "Compare Products", icon: "⚖️" },
    { key: "pharm-interactions", label: "Drug Interactions", icon: "⚠️" },
    { key: "pharm-queries", label: "Query History", icon: "📋" },
    { key: "profile", label: "My Profile", icon: "👤" },
  ],
  admin: [
    { key: "admin-dash", label: "Dashboard", icon: "📊" },
    { key: "admin-meds", label: "Medicines", icon: "💊" },
    { key: "admin-users", label: "Users", icon: "👥" },
    { key: "admin-reports", label: "Reports", icon: "📈" },
    { key: "admin-logs", label: "Audit Logs", icon: "📝" },
    { key: "chat", label: "AI Chatbot", icon: "💬" },
  ],
};

export function MediBotLogo({ size = 32 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2">
      <div
        className="relative rounded-xl bg-gradient-to-br from-brand-500 to-cyan-500 flex items-center justify-center text-white font-bold shadow-md shadow-cyan-500/30"
        style={{ width: size, height: size }}
      >
        <svg viewBox="0 0 24 24" fill="none" className="w-[60%] h-[60%]"><path d="M12 3v18M3 12h18" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /></svg>
      </div>
      <div className="leading-none">
        <div className="font-bold text-base tracking-tight">MediBot</div>
        <div className="text-[10px] text-slate-500 dark:text-slate-400 -mt-0.5">AI Medicine Assistant</div>
      </div>
    </div>
  );
}

export function AppShell({ page, setPage, children }: { page: PageKey; setPage: (p: PageKey) => void; children: ReactNode }) {
  const { currentUser, logout, theme, toggleTheme } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);

  if (!currentUser) return <>{children}</>;
  const nav = ROLE_NAV[currentUser.role];

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-950">
      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:sticky top-0 z-40 h-screen w-64 shrink-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 transition-transform",
        mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <div className="h-16 px-5 flex items-center border-b border-slate-200 dark:border-slate-800">
          <button onClick={() => setPage(currentUser.role === "admin" ? "admin-dash" : "chat")}>
            <MediBotLogo />
          </button>
        </div>
        <nav className="p-3 space-y-1">
          {nav.map((n) => (
            <button
              key={n.key}
              onClick={() => { setPage(n.key); setMobileOpen(false); }}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition",
                page === n.key
                  ? "bg-gradient-to-r from-brand-500/15 to-cyan-500/10 text-brand-700 dark:text-brand-300 font-medium"
                  : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/60"
              )}
            >
              <span className="text-lg">{n.icon}</span>
              <span>{n.label}</span>
              {page === n.key && <span className="ml-auto h-2 w-2 rounded-full bg-brand-500" />}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 inset-x-0 p-3 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
          <div className="flex items-center gap-3 mb-2 px-2">
            <div className="h-9 w-9 rounded-full bg-gradient-to-br from-brand-500 to-cyan-500 text-white font-semibold flex items-center justify-center">
              {currentUser.name.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{currentUser.name}</p>
              <p className="text-xs text-slate-500 capitalize">{currentUser.role}</p>
            </div>
          </div>
          <Button variant="outline" size="sm" className="w-full" onClick={logout}>Sign out</Button>
        </div>
      </aside>

      {mobileOpen && <div className="lg:hidden fixed inset-0 bg-slate-900/50 z-30" onClick={() => setMobileOpen(false)} />}

      {/* Main */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-20 h-16 bg-white/80 dark:bg-slate-900/80 backdrop-blur border-b border-slate-200 dark:border-slate-800">
          <div className="h-full px-4 lg:px-8 flex items-center justify-between">
            <button className="lg:hidden p-2" onClick={() => setMobileOpen(true)}>
              <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 6h16M4 12h16M4 18h16" strokeLinecap="round"/></svg>
            </button>
            <div className="hidden lg:flex items-center gap-2 text-sm text-slate-500">
              <span>MediBot</span>
              <span>/</span>
              <span className="text-slate-900 dark:text-slate-100 font-medium capitalize">{nav.find(n => n.key === page)?.label || "Home"}</span>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="theme">
                {theme === "light" ? "🌙" : "☀️"}
              </Button>
            </div>
          </div>
        </header>

        <main className="flex-1 min-h-0">{children}</main>
      </div>
    </div>
  );
}
