/**
 * Tiny safe markdown renderer for chat messages.
 * Supports: ### headings, **bold**, *italic*, `code`,
 * - / • bullet lists, > blockquotes, simple GFM tables, line breaks.
 */
import { Fragment, type ReactElement, type ReactNode } from "react";

function inline(text: string): ReactNode[] {
  const safe = text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const parts: ReactNode[] = [];
  const regex = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let last = 0; let m: RegExpExecArray | null; let i = 0;
  while ((m = regex.exec(safe)) !== null) {
    if (m.index > last) parts.push(safe.slice(last, m.index));
    const t = m[0];
    if (t.startsWith("**")) parts.push(<strong key={i++}>{t.slice(2, -2)}</strong>);
    else if (t.startsWith("`")) parts.push(<code key={i++} className="px-1 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-xs">{t.slice(1, -1)}</code>);
    else parts.push(<em key={i++}>{t.slice(1, -1)}</em>);
    last = m.index + t.length;
  }
  if (last < safe.length) parts.push(safe.slice(last));
  return parts.map((p) => typeof p === "string" ? p.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">") : p);
}

export function Markdown({ source }: { source: string }) {
  const lines = source.split("\n");
  const out: ReactElement[] = [];
  let i = 0; let key = 0;

  while (i < lines.length) {
    const line = lines[i];

    if (line.includes("|") && lines[i + 1]?.match(/^\s*\|?[\s:|-]+\|/)) {
      const header = line.split("|").map((c) => c.trim()).filter(Boolean);
      i += 2;
      const rows: string[][] = [];
      while (i < lines.length && lines[i].includes("|")) {
        rows.push(lines[i].split("|").map((c) => c.trim()).filter(Boolean));
        i++;
      }
      out.push(
        <div key={key++} className="overflow-x-auto my-2">
          <table className="text-sm w-full border-collapse">
            <thead>
              <tr>{header.map((h, j) => <th key={j} className="text-left px-3 py-2 border-b border-slate-200 dark:border-slate-700 font-semibold">{inline(h)}</th>)}</tr>
            </thead>
            <tbody>
              {rows.map((r, j) => (
                <tr key={j} className="border-b border-slate-100 dark:border-slate-800/60">
                  {r.map((c, k) => <td key={k} className="px-3 py-2 align-top">{inline(c)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      continue;
    }

    if (line.startsWith("### ")) { out.push(<h3 key={key++} className="font-semibold text-base mt-2 mb-1">{inline(line.slice(4))}</h3>); i++; continue; }
    if (line.startsWith("## ")) { out.push(<h2 key={key++} className="font-semibold text-lg mt-2 mb-1">{inline(line.slice(3))}</h2>); i++; continue; }
    if (line.startsWith("> ")) { out.push(<blockquote key={key++} className="border-l-4 border-brand-400 pl-3 my-1 italic text-slate-700 dark:text-slate-300">{inline(line.slice(2))}</blockquote>); i++; continue; }

    if (/^[•\-]\s/.test(line)) {
      const items: string[] = [];
      while (i < lines.length && /^[•\-]\s/.test(lines[i])) {
        items.push(lines[i].replace(/^[•\-]\s/, ""));
        i++;
      }
      out.push(
        <ul key={key++} className="list-disc pl-5 space-y-0.5 my-1">
          {items.map((it, j) => <li key={j}>{inline(it)}</li>)}
        </ul>
      );
      continue;
    }

    if (line.trim() === "") { out.push(<div key={key++} className="h-2" />); i++; continue; }

    out.push(<p key={key++} className="leading-relaxed">{inline(line)}</p>);
    i++;
  }

  return <Fragment>{out}</Fragment>;
}
