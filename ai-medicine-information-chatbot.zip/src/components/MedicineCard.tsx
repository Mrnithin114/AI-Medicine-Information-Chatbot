import type { Medicine } from "../types";
import { useApp } from "../store";
import { Badge, Card } from "./ui";
import { cn } from "../utils/cn";

export function MedicineCard({ m, onOpen }: { m: Medicine; onOpen?: (m: Medicine) => void }) {
  const { currentUser, toggleFavorite } = useApp();
  const isFav = currentUser?.favorites.includes(m.id);
  return (
    <Card className="overflow-hidden group hover:-translate-y-1 hover:shadow-xl transition-all duration-300 cursor-pointer" onClick={() => onOpen?.(m)}>
      <div className={cn("h-24 bg-gradient-to-br relative flex items-center justify-center", m.color)}>
        <span className="text-5xl drop-shadow-md group-hover:scale-110 transition-transform">{m.image}</span>
        {currentUser && (
          <button
            onClick={(e) => { e.stopPropagation(); toggleFavorite(m.id); }}
            className="absolute top-2 right-2 h-8 w-8 rounded-full bg-white/90 dark:bg-slate-900/80 flex items-center justify-center hover:scale-110 transition"
            aria-label="favorite"
          >
            <span className={cn(isFav ? "text-rose-500" : "text-slate-400")}>{isFav ? "♥" : "♡"}</span>
          </button>
        )}
        {m.prescription && (
          <span className="absolute top-2 left-2 text-[10px] uppercase tracking-wide font-bold px-2 py-0.5 rounded-full bg-rose-600 text-white">Rx</span>
        )}
      </div>
      <div className="p-4 space-y-2">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 leading-tight">{m.brand}</h3>
            <p className="text-xs text-slate-500">{m.generic}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <Badge color="brand">{m.form}</Badge>
          <Badge color="slate">{m.strength}</Badge>
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2">{m.uses.slice(0, 2).join(" • ")}</p>
        <div className="flex items-center justify-between pt-1 text-xs text-slate-500">
          <span>{m.manufacturer}</span>
          <span className="tabular-nums">🔍 {m.searches}</span>
        </div>
      </div>
    </Card>
  );
}
