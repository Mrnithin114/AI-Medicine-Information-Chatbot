import type { ButtonHTMLAttributes, HTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from "react";
import { cn } from "../utils/cn";

export function Button({
  className, variant = "primary", size = "md", ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" | "outline" | "danger"; size?: "sm" | "md" | "lg" | "icon" }) {
  const base = "inline-flex items-center justify-center gap-2 font-medium rounded-xl transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500/60 disabled:opacity-50 disabled:pointer-events-none";
  const variants = {
    primary: "bg-gradient-to-r from-brand-500 to-cyan-500 text-white shadow-sm hover:shadow-lg hover:shadow-cyan-500/20 active:translate-y-px",
    secondary: "bg-slate-900 text-white hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600",
    ghost: "text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800",
    outline: "border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/50",
    danger: "bg-rose-600 text-white hover:bg-rose-700",
  };
  const sizes = { sm: "h-8 px-3 text-sm", md: "h-10 px-4 text-sm", lg: "h-12 px-6 text-base", icon: "h-10 w-10" };
  return <button className={cn(base, variants[variant], sizes[size], className)} {...props} />;
}

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("rounded-2xl bg-white dark:bg-slate-900/70 border border-slate-200 dark:border-slate-800 shadow-sm", className)} {...props} />;
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "w-full h-11 px-4 rounded-xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700",
        "text-slate-900 dark:text-slate-100 placeholder:text-slate-400",
        "focus:outline-none focus:ring-2 focus:ring-brand-500/50 focus:border-brand-500/50 transition",
        className
      )}
      {...props}
    />
  );
}

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(
        "w-full px-4 py-3 rounded-xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700",
        "text-slate-900 dark:text-slate-100 placeholder:text-slate-400",
        "focus:outline-none focus:ring-2 focus:ring-brand-500/50 transition resize-y min-h-[88px]",
        className
      )}
      {...props}
    />
  );
}

export function Select({ className, children, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      className={cn(
        "h-11 px-3 rounded-xl bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700",
        "text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-brand-500/50 transition",
        className
      )}
      {...props}
    >
      {children}
    </select>
  );
}

export function Badge({ children, color = "brand", className }: { children: ReactNode; color?: "brand" | "green" | "red" | "amber" | "slate" | "violet"; className?: string }) {
  const map = {
    brand: "bg-brand-100 text-brand-800 dark:bg-brand-900/40 dark:text-brand-200",
    green: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
    red: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300",
    amber: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
    slate: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
    violet: "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300",
  };
  return <span className={cn("inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium", map[color], className)}>{children}</span>;
}

export function Disclaimer({ compact = false }: { compact?: boolean }) {
  return (
    <div className={cn(
      "flex items-start gap-2 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-200 text-xs",
      compact ? "px-3 py-2" : "px-3.5 py-2.5"
    )}>
      <span className="mt-0.5">⚠️</span>
      <p>
        <strong>Medical disclaimer:</strong> MediBot provides information from approved product data and is <strong>not a substitute</strong> for professional medical advice, diagnosis, or treatment. Always consult a qualified healthcare provider. For emergencies, call your local emergency number.
      </p>
    </div>
  );
}

export function Modal({ open, onClose, children, title }: { open: boolean; onClose: () => void; children: ReactNode; title?: string }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-up" onClick={onClose}>
      <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto thin-scroll rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        {title && (
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800">
            <h3 className="font-semibold text-lg">{title}</h3>
            <Button variant="ghost" size="icon" onClick={onClose}>✕</Button>
          </div>
        )}
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
